# Raquel's Journey to the Sun - Versão Final

## Como Jogar

1. Execute o arquivo `RaquelBeta.exe`
2. Use as setas do teclado para mover a Raquel
3. Pressione ESPAÇO para pular
4. Colete as estrelas e encontre o Ricardo no final
5. Complete o jogo antes do tempo acabar!

## Controles
- Setas ESQUERDA/DIREITA: Mover
- ESPAÇO: Pular
- ENTER: Confirmar seleções no menu

## História
Ajude a Raquel a encontrar o Sol e restaurar a luz ao mundo, enquanto desbloqueia um romance especial no final!

Divirta-se! 🎮✨
